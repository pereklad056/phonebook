<?php

	$host = "localhost";
	$user = "root";
	$pass = "";
	$db = "uni2biz";

	$conn = new mysqli($host, $user, $pass, $db);
	
?>